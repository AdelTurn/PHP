-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2021 at 12:13 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wdv341`
--

-- --------------------------------------------------------

--
-- Table structure for table `arr_reviews`
--

CREATE TABLE `arr_reviews` (
  `review_id` int(11) NOT NULL,
  `review_name` varchar(500) NOT NULL,
  `review_body` longtext NOT NULL,
  `review_img` varchar(500) NOT NULL,
  `review_rating` varchar(2) NOT NULL,
  `review_date` date NOT NULL,
  `review_time` time NOT NULL,
  `review_date_updated` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `arr_reviews`
--

INSERT INTO `arr_reviews` (`review_id`, `review_name`, `review_body`, `review_img`, `review_rating`, `review_date`, `review_time`, `review_date_updated`) VALUES
(1, 'Granite City Review', 'I used to work at Granite City as a server but recently I went back, this time as a guest. I went there with my girlfriend and we were pleasantly surprised to see that not much has changed. We ended up getting the Idaho Nachos and the City Wings as our appetizers and we loved them. The Idaho Nachos were perfectly cooked and the wings were amazingly crispy with delicious sauce. For our entrees I got the Bedda Chedda Burger and my girlfriend got the Chicken Asparagus Linguine. I loved mine and my girlfriend thought hers was good but she said she would not order it again.', 'GCReview.jpg', '10', '2021-12-10', '16:31:40', '2021-12-10'),
(2, 'Biaggi\'s Review', 'I have always been a fan of Biaggi\'s even before I started reviewing restaurants. But recently I went back with they eye of a critic. I went with three of my cousins for a night out. We did not get anything for our appetizer but we did devour the bread that was given to us. At the table they provide you with olive oil, parmesan cheese, salt, and pepper so you can make a little sauce to dip your bread in. For our meals I ordered the chicken parmesan while my three cousins all ordered the chicken alfredo. My meal was wonderful and it is my go-to whenever I go to Biaggi\'s, my cousins all loved their chicken alfredo. For dessert I got the delicious bread pudding and my cousins got the cheese cake and creme brulee. We all loved our desserts to make a great night out!', 'biaggisReview.jpg', '09', '2021-12-06', '16:37:34', '2021-12-06'),
(3, 'Sakura Review', 'Sakura is a Japanese Steakhouse that I went to with my girlfriend on a night out. When we came there it was a bit busy but we got seated relatively quickly. Our waitress was very nice and attentive and answered all of our questions since it was our first times their. We ended up getting some sushi rolls for our appetizers and they were amazing. For our main entrees we were treated to tons of food. Our meals came with soup AND salad. Then our main course came with grilled veggies, fried rice, noodles, and the proteins we ordered. I got steak and chicken while my girlfriend just got chicken. We were both very satisfied with tons of food to take home as we were stuffed by the time we even got to our main meal. It was an amazing experience and I will definitely be back.', 'sakuraReview.jpg', '09', '2021-12-07', '16:47:34', '2021-12-07'),
(4, 'Texas Roadhouse Review', 'I recently went to Texas Roadhouse with some family. We used to go there a lot when I was younger but as I grew up I felt like the quality kept declining. This time around I wanted to really rate it to see if that is true. When we went there we had to wait quite a long time as is typical with Texas Roadhouse but we eventually got seated. We ended up getting a sampler of appetizers because there was a ton of us. We had the fried pickles, loaded potato skins, and the boneless wings. The fried pickles were very good and the boneless wings were pretty good but I definitely have had better. For our main entrees I had the country fried chicken with mashed potatoes and fries. My entrée was very good and incredibly filling as I was unable to finish it all. After this experience I feel like I was wrong about how Texas Roadhouse has been going down hill because for how cheap of a place it is, it is very very good.', 'TRHReview.jpg', '08', '2021-12-08', '16:57:34', '2021-12-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arr_reviews`
--
ALTER TABLE `arr_reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arr_reviews`
--
ALTER TABLE `arr_reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
