<?php 

$date = date_create();

$outputDate = date_format($date, "Y");

?>